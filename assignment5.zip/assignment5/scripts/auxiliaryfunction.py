def c_to_f(C):
    temp = ((9/5) * C) + 32
    return(temp)